# Unity Wwise API

This package adds basic API support for Wwise in Unity.

## Usage

See [Wwise Unity Integration](https://www.audiokinetic.com/library/edge/?source=Unity&id=index.html) for more information about how to use the package.

## Legal

Copyright � 2020 Audiokinetic Inc. All rights reserved.
